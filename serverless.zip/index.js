console.log("Start")

import { Storage } from '@google-cloud/storage';
import fetch from 'node-fetch';
import mailgun from 'mailgun-js';
import dotenv from 'dotenv';
import AWS from 'aws-sdk';

console.log("before")
 
dotenv.config();
const mailg = mailgun({ apiKey: process.env.MAILGUN_API_KEY, domain: process.env.DOMAIN });

 
const dynamoDBName = process.env.DYNAMODB_TABLE_NAME;
console.log(dynamoDBName);
const dynamoDB = new AWS.DynamoDB.DocumentClient();
 
const GCP_decodedPrivateKey = Buffer.from(process.env.GCP_SERVICE_ACCOUNT_KEY, 'base64').toString('utf-8');
const GCP_keyFileJson = JSON.parse(GCP_decodedPrivateKey);
console.log(GCP_keyFileJson);
 
 
const storage = new Storage({
  projectId: process.env.GCP_PROJECTID,
  credentials: GCP_keyFileJson,
});
console.log(storage);
 
 
async function handler(event) {
  try {
    console.log("begining of try");
    if (!event || !event.Records) {
      throw new Error('Invalid event or missing Records');
    }
 
    const snsRecords = event.Records.filter(
      (record) => record.EventSource === 'aws:sns'
    );
    console.log(snsRecords);
 
    for (const snsRecord of snsRecords) {
      if (snsRecord.Sns && snsRecord.Sns.Message) {
        console.log('SNS Message:', snsRecord.Sns.Message);
        const snsMessage = JSON.parse(snsRecord.Sns.Message);
        console.log('SNS Message After parsing:', snsMessage.rejectionReason);

        const userEmail = snsMessage.Email;
        const githubRepoUrl = snsMessage.gitHubReopUrl;
        const bucketName = process.env.GCP_STORAGE_BUCKET_NAME;

        if(snsMessage.rejectionReason){
          console.error('Max attempts reached/ Dealine passed');
          await send_error(userEmail, 'Assignment submission failed'+" "+snsMessage.rejectionReason, snsMessage);
          await track(userEmail, 'Submission Rejected');
          return;
        }

        const fileName = `FirstName_LastName_${Date.now()}.zip`;
 
        const isValidUrl = (url) => {
          try {
            new URL(url);
            return true;
          } catch (error) {
            return false;
          }
        };
        
        if (!isValidUrl(githubRepoUrl)) {
          console.error('Invalid GitHub repository URL');
          await send_error(userEmail, 'Please submit a valid url. Thanks', snsMessage);
          await track(userEmail, 'Submitted url is not valid');
          return;
        }
        
        const response = await fetch(githubRepoUrl);
 
        if (!response.ok) {
          await send(userEmail, 'Error downloading release from GitHub', snsMessage);
          await track(userEmail, 'Error downloading release from GitHub');
          return;
        }
 
        const buffer = await response.buffer();
 
        try {
          await storage.bucket(bucketName).file(fileName).save(buffer);
          await send(userEmail, 'your assignment submission release downloaded and upload successful in gcp bucket', snsMessage);
          await track(userEmail, 'Release download and upload successful');

        } catch (error) {

          await send(userEmail, 'Error uploading release to Google Cloud Storage', snsMessage);
          await track(userEmail, 'Error uploading release to Google Cloud Storage');
          return;
        }
      } else {
        console.error('SNS record does not contain expected message data. Please chekc the record again');
      }
    }
  } catch (error) {
    console.error('Error in handler function:', error);
  }
}
 
async function send(email, message) {
    const gBucket_url = process.env.GCP_STORAGE_BUCKET;
    const data = {
      from: 'Prathmesh Pardeshi <shritejas@shotgunn.info>',
      to: email,
      subject: 'Details of your assignment submission',
      text: message+". GCP BUkcet url for submission is: "+gBucket_url,
    };

    mailg.messages().send(data, (error, body) => {
      if (error) {
        console.error(`Error sending email: ${error.message}`);
        return;
      }
      console.log(`Email sent: ${body.message}`);
    });
  }
 

  async function send_error(email, message) {
   
    const data = {
      from: 'Prathmesh Pardeshi <shritejas@shotgunn.info>',
      to: email,
      subject: 'Details of your assignment submission',
      text: message+" Please try submitting again",
    };

    mailg.messages().send(data, (error, body) => {
      if (error) {
        console.error(`Error sending email: ${error.message}`);
        return;
      }
      console.log(`Email sent: ${body.message}`);
    });
    } 


 
async function track(email, status) {
  const params = {
    TableName: dynamoDBName,
    Item: {
      'emailId': email,
      'sentAt': `${Date.now()}`,
      'status': status,
    },
  };
 
  try {
    await dynamoDB.put(params).promise();
  } catch (error) {
    console.error('Error occured while tracking emails :', error);
  }
}
 
export { handler };